﻿namespace Orchard.Tests.Modules.Roles.Controllers {
    class AdminControllerTests {
    }
}
