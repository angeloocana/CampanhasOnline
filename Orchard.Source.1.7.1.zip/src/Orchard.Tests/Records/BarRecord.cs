namespace Orchard.Tests.Records {
    public class BarRecord {
        public virtual int Id { get; set; }
        public virtual decimal Height { get; set; }
        public virtual decimal Width { get; set; }
    }
}